/**==========================================================================**/
/**                                                                          **/
/**  SOURCE FILE: extract.c                                                  **/
/**                                                                          **/
/**      Purpose: This program  extracts asegment from a binary ephemeris    **/
/**               file. The file name is input from the command line; the    **/
/**               program prompts the user for the start and end times of    **/
/**               the desired data segment.                                  **/
/**                                                                          **/
/**   Programmer: David Hoffman/EG5                                          **/
/**               NASA, Johnson Space Center                                 **/
/**               Houston, TX 77058                                          **/
/**               e-mail: david.a.hoffman1@jsc.nasa.gov                      **/
/**                                                                          **/
/**==========================================================================**/


#include <stdio.h>
#include "ephem_util.h"
#ifndef TYPES_DEFINED
#include "ephem_types.h"
#endif

main (argc, argv)
  char *argv[];
   int argc;
{
  int writeRec = FALSE;

  headOneType  H1;
  headTwoType  H2;
  char         keyIn;
  long int     begData;
  FILE         *inFile,  *outFile;
  double       binRec[ARRAY_SIZE],  sec,  T_start,  T_stop;
  int          day,          hour,  min,  month,    year;

  /*--------------------------------------------------------------------------*/
  /* Open input file (quit if unsuccessful).                                  */
  /*--------------------------------------------------------------------------*/


    if ( argc == 3 ) { 
         inFile = fopen(argv[1],"r");
       }
    else { 
         Warning(1);
         exit(1);
       }
 
   if ( inFile==NULL ) {
       Warning(5);
       exit(1);
     }

  /*--------------------------------------------------------------------------*/
  /* Prompt user for start & stop times.                                      */
  /*--------------------------------------------------------------------------*/

  printf("\n");
  printf("   This program  extracts a segment from a binary ephemeris \n");
  printf("   file. It requires start and stop times for this segment. \n");
  printf("   These can  be input either as a pair of Julian  dates or \n");
  printf("   as a Gregorian  date (in the form day, month, year) plus \n");
  printf("   a Universal Time (in the form  hours, minutes, seconds). \n");
  printf("\n   Input a Julian date (y/n) ?  ");
  
  keyIn = getchar();
  
  if ( keyIn == 'y' || keyIn == 'Y' )     /* This is the easy one (for me...) */
     {
      printf("\n\n   Input Start Time:  "); 
      scanf("%f",&T_start);
      printf("\n\n   Input  Stop Time:  ");
      scanf("%f",&T_stop);
     }
  else                                /*...but this one takes a bit more work */
     {
       /*---------------------------------------------------------------------*/
       /* Input start time & convert to a Julian Date.                        */
       /*---------------------------------------------------------------------*/

       printf("\n\n   NOTE: Seconds is a real number (and thus requires ");
       printf("\n   a decimal point) while everthing else is an integer.");
       printf("\n\n   Input Start Time:    Year ?  ");
       scanf("%d",&year);
       printf("                       Month ?  ");
       scanf("%d",&month);
       printf("                         Day ?  ");
       scanf("%d",&day);
       printf("                        Hour ?  ");
       scanf("%d",&hour);
       printf("                      Minute ?  ");
       scanf("%d",&min);
       printf("                     Seconds ?  ");
       scanf("%f",&sec);
       
       T_start = Gregorian_to_Julian(year, month, day, hour, min, sec );
       
       /*---------------------------------------------------------------------*/
       /* Input start time & convert to a Julian Date.                        */
       /*---------------------------------------------------------------------*/

       printf("\n\n   Input Stop Time:    Year ?  ");
       scanf("%d",&year);
       printf("                      Month ?  ");
       scanf("%d",&month);
       printf("                        Day ?  ");
       scanf("%d",&day);
       printf("                       Hour ?  ");
       scanf("%d",&hour);
       printf("                     Minute ?  ");
       scanf("%d",&min);
       printf("                    Seconds ?  ");
       scanf("%f",&sec);

       T_stop = Gregorian_to_Julian(year, month, day, hour, min, sec );

     } /*................................................END: if keyIn == yes */

  /*--------------------------------------------------------------------------*/
  /* Read header records from input file.                                     */
  /*--------------------------------------------------------------------------*/
  
  fread(&H1,sizeof(double),ARRAY_SIZE,inFile);
  fread(&H2,sizeof(double),ARRAY_SIZE,inFile);

  /*--------------------------------------------------------------------------*/
  /* Check validity of T_start & T_stop.                                      */
  /*--------------------------------------------------------------------------*/

  if ( T_start > T_stop ) {
       Warning(23);
       exit(1);
     }

  begData = ftell(inFile);                      /* Ephemeris data starts here */

  fread(&binRec,sizeof(double),ARRAY_SIZE,inFile);       /* Read first record */
  
  if ( T_start < binRec[0] ) {             /* Not valid; print warning & quit */
       Warning(14);
       exit(1);
     }

  fseek(inFile,-ARRAY_SIZE*sizeof(double),SEEK_END);   /* Move to last record */
  fread(&binRec,sizeof(double),ARRAY_SIZE,inFile);                 /* Read it */
  
  if ( T_stop > binRec[1] ) {              /* Not valid; print warning & quit */
       Warning(15);
       exit(1);
     }

  fseek(inFile,begData,SEEK_SET);        /* Return to start of ephemeris data */

  /*--------------------------------------------------------------------------*/
  /* Open output file, then write header records to it.                       */
  /*--------------------------------------------------------------------------*/

  outFile = fopen(argv[2],"w");

  if (outFile==NULL) {                                /* Quit if unsuccessful */
       Warning(4);
       exit(1);
     }

  fwrite(&H1,sizeof(double),ARRAY_SIZE,outFile);
  fwrite(&H2,sizeof(double),ARRAY_SIZE,outFile);

  /*--------------------------------------------------------------------------*/
  /* Extract data segment (Main Loop).                                        */
  /*--------------------------------------------------------------------------*/

  while (!feof(inFile)) 
      {
        /*...................................................Read next record */
      
        fread(&binRec,sizeof(double),ARRAY_SIZE,inFile);
        
        /*.................If record interval brackets T_start, begin writing */
        
        if ((T_start >= binRec[0]) & (T_start <= binRec[1])) writeRec = TRUE;
        
        /*..........................................Write record if requested */

        if (writeRec) fwrite(&binRec,sizeof(double),ARRAY_SIZE,outFile);

        /*...................If record interval brackets T_stop, stop writing */

        if ((T_stop >= binRec[0]) & (T_stop <= binRec[1])) writeRec = FALSE;

      }

  /*--------------------------------------------------------------------------*/
  /* Close files & quit.                                                      */
  /*--------------------------------------------------------------------------*/

  fclose(inFile);
  fclose(outFile);
  
  return 0;

} /**======================================================== END: extract.c **/
