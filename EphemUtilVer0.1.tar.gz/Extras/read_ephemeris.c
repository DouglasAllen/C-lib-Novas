/**==========================================================================**/
/**                                                                          **/
/**  SOURCE FILE: read_ephemeris.c                                           **/
/**                                                                          **/
/**      Purpose: This program provides a means of getting either the state  **/
/**               or the position for a planet from a UNIX shell. It has no  **/
/**               command line arguments; it prompts the user for all of     **/
/**               its required input data.                                   **/
/**                                                                          **/
/**   Programmer: David Hoffman/EG5                                          **/
/**               NASA, Johnson Space Center                                 **/
/**               Houston, TX 77058                                          **/
/**               e-mail: david.a.hoffman1@jsc.nasa.gov                      **/
/**                                                                          **/
/**==========================================================================**/

#include <stdio.h>
#include "ephem_util.h"
#include "ephem_read.h"
#ifndef TYPES_DEFINED
#include "ephem_types.h"
#endif

void main()
{
  stateType  State;
  char       ephemFileName[12], keyIn;
  double     Position[3] , Time , sec;
  int        getState, i, day, hour, min, month, Planet, year;

  /*--------------------------------------------------------------------------*/
  /*  Prompt user for required inputs.                                        */
  /*--------------------------------------------------------------------------*/

  printf("\n");
  printf("   This program reads an ephemeris file and returns either the   \n");
  printf("   position or a position and velocity combination, for a given  \n");
  printf("   planet. You will be prompted to provide all of the required   \n");
  printf("   for this program.                                             \n");
  
  /*................................................Input Ephemeris File Name */

  printf("\n   What is the name of the ephemeris file? ");
  scanf("%s",&ephemFileName);

  /*...................................................Input Planet Selection */

  printf("\n\n   Choose a target:              \n");
  printf("\n         1. Mercury                  ");
  printf("\n         2. Venus                    ");
  printf("\n         3. Earth-Moon Barycenter    ");
  printf("\n         4. Mars                     ");
  printf("\n         5. Jupiter                  ");
  printf("\n         6. Saturn                   ");
  printf("\n         7. Uranus                   ");
  printf("\n         8. Neptune                  ");
  printf("\n         9. Pluto                    ");
  printf("\n        10. Moon -- Geocentric State ");
  printf("\n        11. Sun  -- Geocentric State ");
  printf("\n\n   Input your selection by choosing its number: ");

  scanf("%d",&Planet);
  
  Planet = Planet - 1;                           /* Arrays start with zero... */

  /*.....................................................Input Ephemeris Time */


  printf("   The time can take the form of a Julian date, where the time   \n");
  printf("   of day is given as a fraction, or the form of a conventional  \n");
  printf("   civil date/time combination.                                  \n");
  printf("\n   Input a Julian date (y/n) ? ");  
  
  keyIn = getchar();                        /* Catch <cr> from previous entry */
  keyIn = getchar();
  
  if ( keyIn == 'y' || keyIn == 'Y' )        /* This is the easy one (for me) */
     {
       printf("\n   Input Julian Date: "); 
       scanf("%lf",&Time);
     }
  else                                   /*...but this one requires more work */
     {
       printf("\n\n   NOTE: Seconds is a real number, and thus requires a ");
       printf("\n   decimal point, while everthing else is an integer.");
       printf("\n\n   Input Start Time:    Year? ");
       scanf("%d",&year);
       printf("\n                        Month? ");
       scanf("%d",&month);
       printf("\n                         Day? ");
       scanf("%d",&day);
       printf("\n                        Hour? ");
       scanf("%d",&hour);
       printf("\n                      Minute? ");
       scanf("%d",&min);
       printf("\n                     Seconds? ");
       scanf("%lf",&sec);
       
       Time = Gregorian_to_Julian( year, month, day, hour, min, sec );
     }

  /*...........................................Input State/Position Selection */
  
  printf("\n   Want a position or a state (p/s) ? ");  
  
  keyIn = getchar();                        /* Catch <cr> from previous entry */
  keyIn = getchar();
  
  if (keyIn == 's' || keyIn == 'S')                     /* Set flag for later */
      getState = TRUE;
  else
      getState = FALSE;
  
  /*--------------------------------------------------------------------------*/
  /*  Initialize the ephemeris.                                               */
  /*--------------------------------------------------------------------------*/

  Initialize_Ephemeris(ephemFileName);

  /*--------------------------------------------------------------------------*/
  /*  Compute the desired ephemeris data.                                     */
  /*--------------------------------------------------------------------------*/

  if (getState) 
      Interpolate_State( Time , Planet , &State );
  else
      Interpolate_Position( Time , Planet , Position );

  /*--------------------------------------------------------------------------*/
  /*  Print the answer.                                                       */
  /*--------------------------------------------------------------------------*/

  if ( getState ) 
     {
       printf("\n\n   ");
       for ( i=0 ; i<63 ; i++ ) putchar('-');
       printf("\n\n   Position: [1] = % 16.3f  km",State.Position[0]);
       printf("   Velocity: [1] = % 4.6f  km/sec",State.Velocity[0]);
       printf("\n             [2] = % 16.3f  km",State.Position[1]);
       printf("             [2] = % 4.6f  km/sec",State.Velocity[1]);
       printf("\n             [3] = % 16.3f  km",State.Position[2]);
       printf("             [3] = % 4.6f  km/sec\n\n",State.Velocity[2]);
     }
  else
     {
       printf("\n\n   ");
       for ( i=0 ; i<63 ; i++ ) putchar('-');
       printf("\n\n   Position: [1] = % 16.3f  km",Position[0]);
       printf("\n             [2] = % 16.3f  km",Position[1]);
       printf("\n             [3] = % 16.3f  km\n\n",Position[2]);
     }

} /**================================================= End: read_ephemeris.c **/
