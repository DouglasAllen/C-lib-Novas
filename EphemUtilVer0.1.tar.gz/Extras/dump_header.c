/**==========================================================================**/
/**                                                                          **/
/**  SOURCE FILE: dump_header.c                                              **/
/**                                                                          **/
/**      Purpose: To dump raw character data from header files.              **/
/**                                                                          **/
/**   Programmer: David Hoffman/EG5                                          **/
/**               NASA, Johnson Space Center                                 **/
/**               Houston, TX 77058                                          **/
/**               e-mail: david.a.hoffman1@jsc.nasa.gov                      **/
/**                                                                          **/
/**==========================================================================**/


#include <stdio.h>
#ifndef TYPES_DEFINED
#include "ephem_types.h"
#endif

main (argc, argv)
  char *argv[];
   int argc;
{
  union value {
       char Byte[8];
     double Real;
        int Natural;
  } X;

  int Accumulate = FALSE;
  int Count      = 0;
  int Done       = FALSE;

  char  H1[ARRAY_SIZE*sizeof(double)];
  int   byte, RecSize;
  FILE *inFile;
  
  /*--------------------------------------------------------------------------*/
  /* Initialize Program                                                       */
  /*--------------------------------------------------------------------------*/

  /*.........................................Open file (quit if unsuccessful) */

  if  ( argc == 2 ) 
      {
        inFile  = fopen(argv[1],"r");
        if ( inFile==NULL ) 
           {
             if (inFile==NULL) 
                {
                  printf("\n\n   Can't Open File. \n\n");
                }
             return 1;
           }
      }
  else
     {
       printf("\n\n   Need File Name. \n\n");
       return 1;
     }

  /*...................................................Compute Size of Record */

  RecSize = ARRAY_SIZE * sizeof(double);

  printf("\n   Array Size = %4d\n",RecSize);

  /*--------------------------------------------------------------------------*/
  /* Examine Header Data                                                      */
  /*--------------------------------------------------------------------------*/

  /*.................................................Read First Header Record */

  fread(&H1,sizeof(double),ARRAY_SIZE,inFile);

  /*.......................................................Print Table Header */

  printf("\n   Byte     Hex    Char   Integer     Double  ");
  printf("\n   ------------------------------------------\n");

  /*....................................Enter Main Loop: Print Contents of H1 */

  for ( byte=0 ; byte<RecSize ; byte++ )
      {
      /*...............................Decide If Numerical Values Are Present */

      if ( byte > 2651 )  Accumulate = TRUE;
      /*................................................Build Numerical Value */

      if ( Accumulate == TRUE )
         {
           X.Byte[Count] = H1[byte];                      /* Accumulate bytes */
           Count = Count + 1;                             /*       Count them */

           if ( Count == 8 ) 
              {
                Done  = TRUE;                             /* Signal when done */
                Count = 0;                                /*       Start over */
              }
         }

      /*.....................Print Current Byte and Available Numberic Values */

      if ( Done == TRUE )
         {
           Done = FALSE;
           printf("   %4d    %#4X    %4c",byte,H1[byte],H1[byte]);
           printf("   %6ld   %1.9le\n",X.Natural,X.Real);
         }
      else
         {
           printf("   %4d    %#4X    %4c\n",byte,H1[byte],H1[byte]);
         }

      }

  /*--------------------------------------------------------------------------*/
  /* Clean up & quit.                                                         */
  /*--------------------------------------------------------------------------*/

  printf("\n");
  return 0;

} /**==================================================== End: dump_header.c **/
